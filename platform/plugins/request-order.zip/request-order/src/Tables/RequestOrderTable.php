<?php

namespace Botble\RequestOrder\Tables;
 
use Botble\RequestOrder\Models\RequestOrder;
use Illuminate\Contracts\Routing\UrlGenerator;
use Yajra\DataTables\DataTables;
use Html;
use Botble\Table\Abstracts\TableAbstract;

class RequestOrderTable extends TableAbstract
{
    public function __construct(DataTables $table, UrlGenerator $urlGenerator)
    {
        parent::__construct($table, $urlGenerator);

        $this->setAjaxUrl(route('request-order.index'));
    }

    public function query()
    {
        $query = RequestOrder::select(['id', 'name', 'phone', 'product_name', 'created_at']);
        return $this->applyScopes($query);
    }

    public function columns(): array
    {
        return [
            'id' => ['title' => 'ID', 'width' => '20px'],
            'name' => ['title' => 'Name'],
            'phone' => ['title' => 'Phone'],
            'product_name' => ['title' => 'Product'],
            'created_at' => ['title' => 'Created At'],
        ];
    }

    public function buttons(): array
    {
        return $this->addCreateButton(route('request-order.create'), 'request-order.create');
    }

    public function actions(): array
    {
        return $this->addDeleteAction(route('request-order.deletes'), 'request-order.destroy');
    }
}
