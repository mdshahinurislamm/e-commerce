<?php

namespace Botble\RequestOrder\Http\Controllers\Front;

use Botble\Base\Facades\BaseHelper;
use Botble\Base\Http\Actions\DeleteResourceAction;
use Botble\Base\Http\Controllers\BaseController;
use Botble\RequestOrder\Models\RequestOrder;
use Botble\RequestOrder\Forms\RequestOrderForm;
use Botble\RequestOrder\Http\Requests\EditRequestOrderRequest;
use Botble\RequestOrder\Tables\RequestOrderTable;
use Illuminate\Support\Facades\View;

class RequestOrderController extends BaseController
{
    // public function index(RequestOrderTable $dataTable)
    // {
    //     $this->pageTitle(trans('plugins/request-order::request-order.name'));

    //     return $dataTable->renderTable();
    // }

    public function edit(RequestOrder $requestOrder)
    {
        $this
            ->breadcrumb()
            ->add(trans('plugins/request-order::request-order.name'), route('request-orders.index'));

        $this->pageTitle(trans('plugins/request-order::request-order.edit'));

        return RequestOrderForm::createFromModel($requestOrder)->renderForm();
    }

    public function update(RequestOrder $requestOrder, EditRequestOrderRequest $request)
    {
        RequestOrderForm::createFromModel($requestOrder)->setRequest($request)->save();

        return $this
            ->httpResponse()
            ->setPreviousRoute('request-orders.index')
            ->withUpdatedSuccessMessage();
    }

    // public function destroy(RequestOrder $requestOrder)
    // {
    //     return DeleteResourceAction::make($requestOrder);
    // }




    public function index()
    {        
        $this->pageTitle('Request Orders');

        $orders = RequestOrder::latest()->get();

       // dd($orders);

        return \View::file(base_path('platform/plugins/request-order/resources/views/index.blade.php'), [
            'orders' => $orders,
        ]);

    }

    public function destroy($id)
    {
        $order = RequestOrder::findOrFail($id);
        $order->delete();

        // return Response::json([
        //     'message' => 'Deleted successfully.',
        //     'status' => true,
        // ]);

         return redirect()->back()->with('success', 'Deleted successfully.');
    }








}
