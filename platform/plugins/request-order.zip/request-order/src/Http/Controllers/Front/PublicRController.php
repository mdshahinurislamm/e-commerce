<?php

namespace Botble\RequestOrder\Http\Controllers\Front;

use Botble\Base\Http\Controllers\BaseController;
use Illuminate\Http\Request;
use Botble\RequestOrder\Models\RequestOrder;
use Illuminate\Support\Facades\View;
use RvMedia;



class PublicRController extends BaseController
{
    // public function postSendRequestOrder(Request $request)
    // {
        // $request->validate([
        //     'name' => 'required|max:120',
        //     'phone' => 'required|max:20',
        //     'address' => 'nullable|string',
        //     'note' => 'nullable|string',
        //     'product_name' => 'required|string',
        //     'image' => 'nullable|image|max:2048',
        // ]);

    //     $data = $request->only(['name', 'phone', 'address', 'note', 'product_name']);

    //     if ($request->hasFile('image')) {
    //         $data['image'] = $request->file('image')->store('request-orders');
    //     }

    //     RequestOrder::create($data);

    //     return redirect()->back()->with('success', 'Your request has been submitted!');
    // }


    public function showForm()
    {
        return View::file(base_path('platform/plugins/request-order/resources/views/form.blade.php'));
    }

    public function prescription()
    {
        return View::file(base_path('platform/plugins/request-order/resources/views/prescription.blade.php'));
    }


    public function submit(Request $request)
    {
        //dd($request->all());

        // $request->validate([
        //     'name' => 'required|max:20',
        //     'phone' => 'required|max:11',
        //     'address' => 'nullable|string',
        //     'note' => 'nullable|string',
        //     'product_name' => 'required',
        //     'image' => 'nullable|image|max:2048',
        // ]);

        $allProducts = $request->products;

        //dd($allProducts);

        //$data = $request->only(['name', 'phone', 'address', 'product_name' => $allProducts, 'extra_note']);
         $data = [
            'name' => $request->input('name'),
            'phone' => $request->input('phone'),
            'address' => $request->input('address'),
            'product_name' => json_encode($allProducts),
            'extra_note' => $request->input('extra_note'),
        ];
        
        if ($request->hasFile('image')) {
            $data['image'] = RvMedia::handleUpload($request->file('image'), 0, 'request-orders')['data']['url'] ?? null;
        }

       // dd($data);

        RequestOrder::create($data);

        return redirect()->back()->with('success', 'Your request has been submitted!');
    }
}
