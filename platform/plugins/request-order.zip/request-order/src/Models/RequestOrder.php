<?php

namespace Botble\RequestOrder\Models;

use Botble\Base\Models\BaseModel;

class RequestOrder extends BaseModel
{
    protected $table = 'request_orders';

    protected $fillable = [
        'name', 'phone', 'address', 'product_name', 'extra_note', 'image',
    ];
}
