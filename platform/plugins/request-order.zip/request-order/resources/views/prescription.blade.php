@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif





<form action="{{ route('request-order.submit') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <input type="text" name="name" placeholder="Name" required><br>
    <input type="text" name="phone" placeholder="Phone" required><br>
    <input type="text" name="address" placeholder="Address" required><br>
    <input type="hidden" name="product_name" value="Prescription" placeholder="Product Name"><br>
    <textarea name="extra_note" placeholder="Extra Note"></textarea><br>
    <input type="file" name="image"><br>
    <button type="submit">Submit Order</button>
</form>








<!-- <style>
  .field-group {
    margin-bottom: 10px;
    border: 1px solid #ddd;
    padding: 10px;
    display: flex;
    gap: 10px;
    align-items: center;
  }
  .field-group input {
    padding: 5px;
    flex: 1;
  }
  .field-group button {
    padding: 5px 10px;
  }
</style>

<form id="myForm" method="POST" action="{{ route('request-order.submit') }}" enctype="multipart/form-data">
    @csrf    
    <input type="text" name="name" placeholder="Name" required><br>
    <input type="text" name="phone" placeholder="Phone" required><br>
    <input type="text" name="address" placeholder="Address" required><br> 
    <textarea name="extra_note" placeholder="Extra Note"></textarea><br>
    <input type="file" name="image"><br>
    



  <h3>Products:</h3>
  <div id="productsContainer">
    <div class="field-group">
      <input type="text" name="products[0][product_name]" placeholder="Product Name" required />
      <input type="text" name="products[0][price]" placeholder="Strength" required />
      <input type="number" name="products[0][quantity]" placeholder="Quantity" min="1" required />
      <button type="button" onclick="removeGroup(this)">Remove</button>
    </div>
  </div>

  <button type="button" onclick="addGroup()">Add More</button><br/><br/>

  <button type="submit">Submit</button>
</form> -->

<script>
  let productIndex = 1; // Because we started with index 0

  function addGroup() {
    const container = document.getElementById('productsContainer');
    const div = document.createElement('div');
    div.className = 'field-group';
    div.innerHTML = `
      <input type="text" name="products[${productIndex}][product_name]" placeholder="Product Name" required />
      <input type="number" name="products[${productIndex}][price]" placeholder="Price" min="0" step="0.01" required />
      <input type="number" name="products[${productIndex}][quantity]" placeholder="Quantity" min="1" required />
      <button type="button" onclick="removeGroup(this)">Remove</button>
    `;
    container.appendChild(div);
    productIndex++;
  }

  function removeGroup(button) {
    const group = button.parentNode;
    group.parentNode.removeChild(group);
  }
</script>