@extends('core/base::layouts.master')

@section('content')
    <div class="max-width-1200">
        <h4>Request Order List</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Note</th>
                    <th>Product</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($orders as $order)
                    <tr>
                        <td>{{ $order->name }}</td>
                        <td>{{ $order->phone }}</td>
                        <td>{{ $order->address }}</td>
                        <td>{{ $order->note }}</td>
                        <td>
                            @php
                                $products = json_decode($order->product_name, true);
                            @endphp

                            @if(is_array($products))
                                <ul>
                                    @foreach($products as $product)
                                        <li>
                                            Product: {{ $product['product_name'] ?? '' }},
                                            Strength: {{ $product['price'] ?? '' }},
                                            Quantity: {{ $product['quantity'] ?? '' }}
                                        </li>
                                    @endforeach
                                </ul>
                            @else
                                <p>No products found.</p>
                            @endif
                        </td>
                        <td>
                            @if ($order->image)
                                <img src="{{ \RvMedia::getImageUrl($order->image) }}" alt="" width="80">
                            @endif
                        </td>
                        <td>
                            <form method="POST" action="{{ route('request-order.destroy', $order->id) }}" onsubmit="return confirm('Delete this request?')">
                                @csrf
                                @method('DELETE')
                                <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
