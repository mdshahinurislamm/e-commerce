<?php

use Botble\Base\Facades\AdminHelper;
use Botble\RequestOrder\Http\Controllers\Front\RequestOrderController;
use Botble\RequestOrder\Http\Controllers\Front\PublicRController;
use Illuminate\Support\Facades\Route;

// Route::group(['namespace' => 'Botble\RequestOrder\Http\Controllers\Front'], function () {
//     AdminHelper::registerRoutes(function () {
//         Route::group(['prefix' => 'request-orders', 'as' => 'request-orders.'], function () {
//             Route::resource('', RequestOrderController::class)
//                 ->except(['create', 'store'])
//                 ->parameters(['' => 'request-order']);
//         });
//     });

//     // Frontend public route (optional)
//     Route::group(['middleware' => ['web']], function () {
//         Route::post('request-order/send', [
//             'as' => 'public.send.request-order',
//             'uses' => 'PublicRController@postSendRequestOrder',
//         ]);
//     });
// });


// Route::group(['middleware' => ['web']], function () {
//     Route::get('request-order/form', [
//         'as' => 'request-order.form',
//         'uses' => 'Botble\RequestOrder\Http\Controllers\Front\PublicRController@showForm',
//     ]);

//     Route::post('request-order/send', [
//         'as' => 'public.send.request-order',
//         'uses' => 'Botble\RequestOrder\Http\Controllers\Front\PublicRController@postSendRequestOrder',
//     ]);
// });


Route::group(['namespace' => 'Botble\RequestOrder\Http\Controllers\Front', 'middleware' => ['web']], function () {
    Route::get('request-order/form', [PublicRController::class, 'showForm'])->name('request-order.form');
    Route::get('request-order/prescription', [PublicRController::class, 'prescription'])->name('request-order.prescription');
    Route::post('request-order/submit', [PublicRController::class, 'submit'])->name('request-order.submit');
});



Route::group(['namespace' => 'Botble\RequestOrder\Http\Controllers\Front', 'middleware' => ['web', 'core']], function () {
    AdminHelper::registerRoutes(function () {
    Route::group(['prefix' => 'request-orders', 'as' => 'request-order.'], function () {
        Route::get('/', [RequestOrderController::class, 'index'])->name('index');
        Route::delete('/{id}', [RequestOrderController::class, 'destroy'])->name('destroy');
    });
});
});
