@extends('core/base::layouts.master')

@section('content')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function() {
        $('#orderTable').DataTable({
            "pageLength": 10,
            pagingType: "simple_numbers",
            // language: {
            //     paginate: {
            //         previous: "←",
            //         next: "→"
            //     }
            // }
        });
    });
</script>

<style>
/* Container */
.dataTables_wrapper .dataTables_paginate {
    display: flex;
    justify-content: center;
    margin-top: 20px;
}

/* Pagination buttons */
.dataTables_wrapper .dataTables_paginate .paginate_button {
    background-color: #f0f0f0;
    border: 1px solid #ccc;
    padding: 6px 12px;
    margin: 0 3px;
    border-radius: 6px;
    color: #333 !important;
    font-weight: 500;
    transition: all 0.2s ease;
}

.dataTables_wrapper .dataTables_paginate .paginate_button:hover {
    background-color: #007bff;
    color: white !important;
    border-color: #007bff;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.current {
    background-color: #007bff;
    color: white !important;
    border-color: #007bff;
    font-weight: bold;
}

/* Disable previous/next buttons */
.dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
    color: #999 !important;
    cursor: not-allowed;
    background-color: #e9ecef;
    border-color: #ddd;
}
</style>



    <div class="max-width-1200">
        <h4>Request Review List</h4>
        <table class="table table-bordered" id="orderTable">
            <thead>
                <tr>
                    <th>Name</th> 
                    <th>Message</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($orders as $order)
                    <tr>
                        <td>{{ $order->name }}</td>
                        <td>{{ $order->message }}</td>                         
                        <td>
                            <form method="POST" action="{{ route('request-review.destroy', $order->id) }}" onsubmit="return confirm('Delete this request?')">
                                @csrf
                                @method('DELETE')
                                <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
