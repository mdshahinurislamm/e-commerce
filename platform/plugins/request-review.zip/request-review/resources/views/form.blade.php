@if (auth('customer')->check())
<form action="{{ route('request-review.submit') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <input type="hidden" name="name" placeholder="Name" value="{{ auth('customer')->user()->name }}" readonly><br>
    <input type="text" name="message" placeholder="Post Your Review Here">
    <button type="submit">Post Review</button>
</form>
@else
<input type="text" name="message" placeholder="Post Your Review Here">
<a href="{{ route('customer.login') }}">{{ __('Post Review') }}</a>
@endif

@if(session('success'))
    <div class="alert alert-success mt-3">{{ session('success') }}</div>
@endif

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function() {
        $.noConflict();
        $('#orderTable2').DataTable({
            "pageLength": 10,
            'searching':false,
            pagingType: "simple_numbers",
            // language: {
            //     paginate: {
            //         previous: "←",
            //         next: "→"
            //     }
            // }
        });
    });
</script>

<style>
/* Container */
.dataTables_wrapper .dataTables_paginate {
    display: flex;
    justify-content: center;
    margin-top: 20px;
}

/* Pagination buttons */
.dataTables_wrapper .dataTables_paginate .paginate_button {
    background-color: #f0f0f0;
    border: 1px solid #ccc;
    padding: 6px 12px;
    margin: 0 3px;
    border-radius: 6px;
    color: #333 !important;
    font-weight: 500;
    transition: all 0.2s ease;
}

.dataTables_wrapper .dataTables_paginate .paginate_button:hover {
    background-color: #007bff;
    color: white !important;
    border-color: #007bff;
}

.dataTables_wrapper .dataTables_paginate .paginate_button.current {
    background-color: #007bff;
    color: white !important;
    border-color: #007bff;
    font-weight: bold;
}

/* Disable previous/next buttons */
.dataTables_wrapper .dataTables_paginate .paginate_button.disabled {
    color: #999 !important;
    cursor: not-allowed;
    background-color: #e9ecef;
    border-color: #ddd;
}
</style>

@php
    use Botble\RequestReview\Models\RequestReview;
    $orders = RequestReview::latest()->get();
@endphp

    <div class="max-width-1200 mt-3">       
        <table class="table table-bordered" id="orderTable2">
            <thead>
                <tr>
                    <th>Review</th> 
                </tr>
            </thead>
            <tbody>
                @foreach ($orders as $order)
                    <tr>
                        <td>{{ $order->name }}<br>
                            {{ $order->message }}<br>
                            <i><b>{{ $order->updated_at }}</b></i>
                        </td> 
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>



