<?php
namespace Botble\RequestReview\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Routing\Events\RouteMatched;
use Illuminate\Support\Facades\Route;
use Botble\Base\Traits\LoadAndPublishDataTrait;
use Illuminate\Support\Facades\View;

class RequestReviewServiceProvider extends ServiceProvider
{
    use LoadAndPublishDataTrait;

    public function boot()
    {
        $this->setNamespace('plugins/request-review')
            ->loadRoutes()
            ->loadAndPublishViews()
            ->loadMigrations();

        $this->app['events']->listen(RouteMatched::class, function () {
            dashboard_menu()->registerItem([
                'id'          => 'cms-plugins-request-review',
                'priority'    => 5,
                'parent_id'   => null,
                'name'        => 'Reviews',
                'icon'        => 'fas fa-user',
                'url'         => route('request-review.index'),
                'permissions' => ['request-review.index'],
            ]);
        });

        //$this->loadViewsFrom(__DIR__ . '/../resources/views', 'plugins.request-order');
        $this->loadViewsFrom(__DIR__ . '/../../resources/views', 'plugins.request-review');

    }

    public function register()
    {
            //$this->app->register(\Botble\RequestOrder\Providers\RequestOrderServiceProvider::class);

    }
}
