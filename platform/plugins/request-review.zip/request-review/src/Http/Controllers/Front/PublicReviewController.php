<?php

namespace Botble\RequestReview\Http\Controllers\Front;

use Botble\Base\Http\Controllers\BaseController;
use Illuminate\Http\Request;
use Botble\RequestReview\Models\RequestReview;
use Illuminate\Support\Facades\View; 
use RvMedia;



class PublicReviewController extends BaseController
{
    public function showForm()
    {
        // return View::file(base_path('platform/plugins/request-review/resources/views/form.blade.php'));        

        $orders = RequestReview::latest()->get();
         
        // return \View::file(base_path('platform/plugins/request-review/resources/views/form.blade.php'), [
        //     'orders' => $reviews,
        // ]);

    $orders = RequestReview::latest()->get();
    // Return the plugin view and pass the $orders variable
    return view('plugins.request-review::form', compact('orders'));



    }

    public function prescription()
    {
        return View::file(base_path('platform/plugins/request-review/resources/views/prescription.blade.php'));
    }


    public function submit(Request $request)
    {
        //dd($request->all());

        // $request->validate([
        //     'name' => 'required|max:20',
        //     'phone' => 'required|max:11',
        //     'address' => 'nullable|string',
        //     'note' => 'nullable|string',
        //     'product_name' => 'required',
        //     'image' => 'nullable|image|max:2048',
        // ]);

        $allProducts = $request->products;

        //dd($allProducts);

        //$data = $request->only(['name', 'phone', 'address', 'product_name' => $allProducts, 'extra_note']);
         $data = [
            'name' => $request->input('name'),
            'message' => $request->input('message'),
        ];      
        

       // dd($data);

        RequestReview::create($data);

        return redirect()->back()->with('success', 'Your request has been submitted!');
    }
}
