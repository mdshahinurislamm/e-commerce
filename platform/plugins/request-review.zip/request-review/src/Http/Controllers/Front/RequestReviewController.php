<?php

namespace Botble\RequestReview\Http\Controllers\Front;

use Botble\Base\Facades\BaseHelper;
use Botble\Base\Http\Actions\DeleteResourceAction;
use Botble\Base\Http\Controllers\BaseController;
use Botble\RequestReview\Models\RequestReview;
use Botble\RequestReview\Forms\RequestReviewForm;
use Botble\RequestReview\Http\Requests\EditRequestReviewRequest;
use Botble\RequestReview\Tables\RequestReviewTable;
use Illuminate\Support\Facades\View;

class RequestReviewController extends BaseController
{
    // public function index(RequestReviewTable $dataTable)
    // {
    //     $this->pageTitle(trans('plugins/request-order::request-order.name'));

    //     return $dataTable->renderTable();
    // }

    public function edit(RequestReview $requestreview)
    {
        $this
            ->breadcrumb()
            ->add(trans('plugins/request-order::request-order.name'), route('request-orders.index'));

        $this->pageTitle(trans('plugins/request-order::request-order.edit'));

        return RequestReviewForm::createFromModel($requestreview)->renderForm();
    }

    public function update(RequestReview $requestreview, EditRequestReviewRequest $request)
    {
        RequestReviewForm::createFromModel($requestreview)->setRequest($request)->save();

        return $this
            ->httpResponse()
            ->setPreviousRoute('request-reviews.index')
            ->withUpdatedSuccessMessage();
    }

    // public function destroy(RequestOrder $requestOrder)
    // {
    //     return DeleteResourceAction::make($requestOrder);
    // }




    public function index()
    {        
        $this->pageTitle('Request Reviews');

        $orders = RequestReview::latest()->get();

       // dd($orders);

        return \View::file(base_path('platform/plugins/request-review/resources/views/index.blade.php'), [
            'orders' => $orders,
        ]);

    }

    public function destroy($id)
    {
        $order = RequestReview::findOrFail($id);
        $order->delete();

        // return Response::json([
        //     'message' => 'Deleted successfully.',
        //     'status' => true,
        // ]);

         return redirect()->back()->with('success', 'Deleted successfully.');
    }








}
