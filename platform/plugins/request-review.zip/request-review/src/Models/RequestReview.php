<?php

namespace Botble\RequestReview\Models;

use Botble\Base\Models\BaseModel;

class RequestReview extends BaseModel
{
    protected $table = 'request_reviews';

    protected $fillable = [
        'name', 'message',
    ];
}
