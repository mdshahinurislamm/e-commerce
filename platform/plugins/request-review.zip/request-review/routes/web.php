<?php

use Botble\Base\Facades\AdminHelper;
use Botble\RequestReview\Http\Controllers\Front\RequestReviewController;
use Botble\RequestReview\Http\Controllers\Front\PublicReviewController;
use Illuminate\Support\Facades\Route;

Route::group(['namespace' => 'Botble\RequestReview\Http\Controllers\Front', 'middleware' => ['web']], function () {
    Route::get('request-review/form', [PublicReviewController::class, 'showForm'])->name('request-review.form');
    Route::get('request-review/prescription', [PublicReviewController::class, 'prescription'])->name('request-review.prescription');
    Route::post('request-review/submit', [PublicReviewController::class, 'submit'])->name('request-review.submit');
});



Route::group(['namespace' => 'Botble\RequestReview\Http\Controllers\Front', 'middleware' => ['web', 'core']], function () {
    AdminHelper::registerRoutes(function () {
    Route::group(['prefix' => 'request-reviews', 'as' => 'request-review.'], function () {
        Route::get('/', [RequestReviewController::class, 'index'])->name('index');
        Route::delete('/{id}', [RequestReviewController::class, 'destroy'])->name('destroy');
    });
});
});
